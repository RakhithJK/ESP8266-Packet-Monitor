# WiFi Nugget Packet Monitor
A simple GUI & serial interface tool to monitor WiFi packets, using the ESP32S2 WiFi microcontroller.  [Click here for the ESP8266 version.](https://github.com/HakCat-Tech/Nugget-Packet-Monitor/tree/ESP8266)  More documentation coming soon.

## Dependencies
[ThingPulse SH1106 Display Library](https://github.com/ThingPulse/esp8266-oled-ssd1306)
